from spherov2.toy.bb8 import BB8
from spherov2.types import ToyType


class Sprk2(BB8):
    toy_type = ToyType('Sphero SPRK+', 'SK-', 'SK', .06)
